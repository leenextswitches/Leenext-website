
import React from "react";
import { useState } from "react";

const products = [
  { id: 1, name: "6A Neo 1 Way Switch", series: "Neo Series" },
  { id: 2, name: "16A Leeplus 1 Way Switch", series: "Leeplus Series" },
  { id: 3, name: "20A Sleek Switch", series: "Sleek Series" },
];

const seriesList = ["All", "Neo Series", "Leeplus Series", "Sleek Series"];

export default function App() {
  const [filter, setFilter] = useState("All");
  const [search, setSearch] = useState("");

  const filteredProducts = products.filter(
    (p) =>
      (filter === "All" || p.series === filter) &&
      p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen p-6 font-sans bg-[#f5f1e6] text-gray-900">
      <header className="text-center mb-8">
        <img src="/logo.png" alt="Leenext Logo" className="h-20 mx-auto mb-2" />
        <h1 className="text-3xl font-bold">Leenext Modular Switches</h1>
        <p className="text-gray-600">Product Catalog</p>
      </header>

      <div className="flex flex-wrap justify-center gap-4 mb-6">
        {seriesList.map((s) => (
          <button
            key={s}
            className={`px-4 py-2 rounded-full border ${
              filter === s ? "bg-black text-white" : "bg-white"
            }`}
            onClick={() => setFilter(s)}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="flex justify-center mb-6">
        <input
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="px-4 py-2 border w-full max-w-md rounded-full"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
        {filteredProducts.map((product) => (
          <div key={product.id} className="bg-white p-4 rounded-xl shadow">
            <h2 className="text-lg font-semibold">{product.name}</h2>
            <p className="text-sm text-gray-500">{product.series}</p>
          </div>
        ))}
      </div>

      <div className="text-center mt-8">
        <a
          href="/Leenext List 2022 P.pdf"
          download
          className="text-blue-600 underline"
        >
          Download Full Catalog (PDF)
        </a>
      </div>
    </div>
  );
}
